// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>

#include <random>

#include <time.h>

// Include GLEW. Always include it before gl.h and glfw3.h, since it's a bit magic.
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <omp.h>

#include "shader.h"
#include "texture.h"
#include "controls.h"

#ifndef M_PI
#define M_PI    3.14159265359
#endif

GLFWwindow* window;

using namespace glm;

bool predicate(int n){
    return n >= 0;
}

glm::highp_f64vec3 generate_mesh_from_geom(std::vector<glm::vec3> temp_vertices, int width, int height, glm::vec3* &vertices, glm::vec2* &uvs, unsigned int* &indices, int &size)
{
    glm::highp_f64vec3 center(0.0, 0.0, 0.0);
    int num_valid_vtx = 0;

    int size_ = width * height;
    bool *check_number = new bool[size_];
    int *check_i = new int[size_];
    int *check_j = new int[size_];

    memset(check_number, false, sizeof(bool) * size_);
    memset(check_i, -1, sizeof(int) * size_);
    memset(check_j, -1, sizeof(int) * size_);

    omp_set_num_threads(8);

    #pragma omp parallel for
    for(int i=0; i<width-1; i++)
    {
        for(int j=0; j<height-1; j++)
        {
            int index0 = j * width + i;
            int index1 = index0 + 1;
            int index2 = (j + 1) * width + i + 1;
            int index3 = index2 - 1; 

            if(temp_vertices[index0].x == -1000 || temp_vertices[index0].y == -1000 || temp_vertices[index0].z == -1000
                || temp_vertices[index1].x == -1000 || temp_vertices[index1].y == -1000 || temp_vertices[index1].z == -1000
                || temp_vertices[index2].x == -1000 || temp_vertices[index2].y == -1000 || temp_vertices[index2].z == -1000
                || temp_vertices[index3].x == -1000 || temp_vertices[index3].y == -1000 || temp_vertices[index3].z == -1000)
                continue;

            check_number[index0] = true;
            check_i[index0] = i;
            check_j[index0] = j;
        }
    }

    num_valid_vtx = std::count(check_number, check_number + size_, true);
    size = num_valid_vtx;

    int *tmp_check_i = new int[num_valid_vtx];
    int *tmp_check_j = new int[num_valid_vtx];

    std::copy_if(check_i, check_i + size_, tmp_check_i, predicate);
    std::copy_if(check_j, check_j + size_, tmp_check_j, predicate);

    vertices = new glm::vec3[num_valid_vtx];
    uvs = new glm::vec2[num_valid_vtx];
    indices = new unsigned int[num_valid_vtx * 6];

    unsigned int *tmp_new_indices = new unsigned int[size_];
    memset(check_j, 0, sizeof(unsigned int) * size_);

    glm::vec3 *l_center = new glm::vec3[num_valid_vtx];

    #pragma omp parallel for
    for(int k=0;k<num_valid_vtx;k++){
        int i = tmp_check_i[k];
        int j = tmp_check_j[k];

        int index0 = j * width + i;

        vertices[k] = temp_vertices[index0];
        uvs[k] = glm::vec2((float)i/width, (float)(height-j)/height);

        tmp_new_indices[index0] = k;

        l_center[k] = temp_vertices[index0];
    }

    for(int i=0;i<num_valid_vtx;i++){
        center += l_center[i];
    }
    center /= num_valid_vtx;


    #pragma omp parallel for
    for(int k=0;k<num_valid_vtx;k++){
        int i = tmp_check_i[k];
        int j = tmp_check_j[k];

        int index0 = j * width + i;
        int index1 = index0 + 1;
        int index2 = (j + 1) * width + i + 1;
        int index3 = index2 - 1; 

        if(tmp_new_indices[index1] == 0 || tmp_new_indices[index2] == 0 || tmp_new_indices[index3] == 0)
            continue;

        indices[k * 6    ] = tmp_new_indices[index0];
        indices[k * 6 + 1] = tmp_new_indices[index2];
        indices[k * 6 + 2] = tmp_new_indices[index1];
        indices[k * 6 + 3] = tmp_new_indices[index0];
        indices[k * 6 + 4] = tmp_new_indices[index3];
        indices[k * 6 + 5] = tmp_new_indices[index2];
    }

    delete check_number;
    delete check_i;
    delete check_j;
    delete tmp_check_i;
    delete tmp_check_j;
    delete tmp_new_indices;

    //std::cout << "Number of Vertices: " << vertices.size() << std::endl;
    return center;

}

glm::highp_f64vec3 read_geom_images(std::string dat_filename, glm::vec3* &vertices, glm::vec2* &uvs, unsigned int* &indices, int &size)
{
    int width, height, step;
    std::vector<glm::vec3> temp_vertices;

    // read position info
	FILE* fp = fopen(dat_filename.c_str(), "rb");
    fread(&width, sizeof(int), 1, fp);
    fread(&height, sizeof(int), 1, fp);
    fread(&step, sizeof(int), 1, fp);

    int img_size = width * height;
	for (int i = 0; i < img_size; i++) {
        float p1, p2, p3;
		fread(&p1, sizeof(float), 1, fp);
		fread(&p2, sizeof(float), 1, fp);
		fread(&p3, sizeof(float), 1, fp);
        temp_vertices.push_back(glm::vec3(p1, p2, p3));
	}
	fclose(fp); 


    // reconstruct mesh from particles
    return generate_mesh_from_geom(temp_vertices, width, height, vertices, uvs, indices, size);

}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// renderCube() renders a 1x1 3D cube in NDC.
// -------------------------------------------------
unsigned int unitcubeVAO = 0;
unsigned int unitcubeVBO = 0;
void renderUnitCube()
{
    // initialize (if necessary)
    if (unitcubeVAO == 0)
    {
        float vertices[] = {
            // back face
            -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 0.0f, // bottom-left
             1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, // top-right
             1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 0.0f, // bottom-right         
             1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, // top-right
            -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 0.0f, // bottom-left
            -1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 1.0f, // top-left
            // front face
            -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 0.0f, // bottom-left
             1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 0.0f, // bottom-right
             1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, // top-right
             1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, // top-right
            -1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 1.0f, // top-left
            -1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 0.0f, // bottom-left
            // left face
            -1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-right
            -1.0f,  1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, // top-left
            -1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-left
            -1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-left
            -1.0f, -1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 0.0f, // bottom-right
            -1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-right
            // right face
             1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-left
             1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-right
             1.0f,  1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, // top-right         
             1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-right
             1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-left
             1.0f, -1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 0.0f, // bottom-left     
            // bottom face
            -1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 1.0f, // top-right
             1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, // top-left
             1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 0.0f, // bottom-left
             1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 0.0f, // bottom-left
            -1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 0.0f, // bottom-right
            -1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 1.0f, // top-right
            // top face
            -1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 1.0f, // top-left
             1.0f,  1.0f , 1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 0.0f, // bottom-right
             1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, // top-right     
             1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 0.0f, // bottom-right
            -1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 1.0f, // top-left
            -1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 0.0f  // bottom-left        
        };
        
        glGenVertexArrays(1, &unitcubeVAO);
        glGenBuffers(1, &unitcubeVBO);
        // fill buffer
        glBindBuffer(GL_ARRAY_BUFFER, unitcubeVBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
        // link vertex attributes
        glBindVertexArray(unitcubeVAO);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }
    // render Cube
    glBindVertexArray(unitcubeVAO);
    glDrawArrays(GL_TRIANGLES, 0, 36);
    glBindVertexArray(0);
}

// renders (and builds at first invocation) a sphere
// -------------------------------------------------

void renderSphere(float radius, glm::vec3 transM)
{
    unsigned int sphereVAO = 0;
    unsigned int indexCount;
    if (sphereVAO == 0)
    {
        glGenVertexArrays(1, &sphereVAO);

        unsigned int vbo, ebo;
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);

        std::vector<glm::vec3> positions;
        std::vector<glm::vec2> uv;
        std::vector<glm::vec3> normals;
        std::vector<unsigned int> indices;

        const unsigned int X_SEGMENTS = 64;
        const unsigned int Y_SEGMENTS = 64;
        const float PI = 3.14159265359;
        for (unsigned int y = 0; y <= Y_SEGMENTS; ++y)
        {
            for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
            {
                float xSegment = (float)x / (float)X_SEGMENTS;
                float ySegment = (float)y / (float)Y_SEGMENTS;
                float xPos = std::cos(xSegment * 2.0f * PI) * std::sin(ySegment * PI);
                float yPos = std::cos(ySegment * PI);
                float zPos = std::sin(xSegment * 2.0f * PI) * std::sin(ySegment * PI);

                positions.push_back(glm::vec3(xPos, yPos, zPos) * radius + transM);
                uv.push_back(glm::vec2(xSegment, ySegment));
                normals.push_back(glm::vec3(xPos, yPos, zPos));
            }
        }

        bool oddRow = false;
        for (unsigned int y = 0; y < Y_SEGMENTS; ++y)
        {
            if (!oddRow) // even rows: y == 0, y == 2; and so on
            {
                for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
                {
                    indices.push_back(y       * (X_SEGMENTS + 1) + x);
                    indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
                }
            }
            else
            {
                for (int x = X_SEGMENTS; x >= 0; --x)
                {
                    indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
                    indices.push_back(y       * (X_SEGMENTS + 1) + x);
                }
            }
            oddRow = !oddRow;
        }
        indexCount = indices.size();

        std::vector<float> data;
        for (std::size_t i = 0; i < positions.size(); ++i)
        {
            data.push_back(positions[i].x);
            data.push_back(positions[i].y);
            data.push_back(positions[i].z);
            if (uv.size() > 0)
            {
                data.push_back(uv[i].x);
                data.push_back(uv[i].y);
            }
            if (normals.size() > 0)
            {
                data.push_back(normals[i].x);
                data.push_back(normals[i].y);
                data.push_back(normals[i].z);
            }
        }
        glBindVertexArray(sphereVAO);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float), &data[0], GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);
        float stride = (3 + 2 + 3) * sizeof(float);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(5 * sizeof(float)));
    }

    glBindVertexArray(sphereVAO);
    glDrawElements(GL_TRIANGLE_STRIP, indexCount, GL_UNSIGNED_INT, 0);
}

// renderQuad() renders a 1x1 XY quad in NDC
// -----------------------------------------
unsigned int quadVAO = 0;
unsigned int quadVBO;
void renderQuad()
{
    if (quadVAO == 0)
    {
        float quadVertices[] = {
            // positions        // texture Coords
            -1.0f,  1.0f, 0.0f, 0.0f, 1.0f,
            -1.0f, -1.0f, 0.0f, 0.0f, 0.0f,
             1.0f,  1.0f, 0.0f, 1.0f, 1.0f,
             1.0f, -1.0f, 0.0f, 1.0f, 0.0f,
        };
        // setup plane VAO
        glGenVertexArrays(1, &quadVAO);
        glGenBuffers(1, &quadVBO);
        glBindVertexArray(quadVAO);
        glBindBuffer(GL_ARRAY_BUFFER, quadVBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), &quadVertices, GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    }
    glBindVertexArray(quadVAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindVertexArray(0);
}

GLuint generateCubemap(Shader* shader_cubemap, GLuint hdrTextureID)
{
    unsigned int envCubemap;
    glGenTextures(1, &envCubemap);
    glBindTexture(GL_TEXTURE_CUBE_MAP, envCubemap);
    for (unsigned int i = 0; i < 6; ++i)
    {
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB16F, 512, 512, 0, GL_RGB, GL_FLOAT, nullptr);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // pbr: set up projection and view matrices for capturing data onto the 6 cubemap face directions
    // ----------------------------------------------------------------------------------------------
    glm::mat4 captureProjection = glm::perspective(glm::radians(90.0f), 1.0f, 0.1f, 10.0f);
    glm::mat4 captureViews[] =
    {
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec3(0.0f,  0.0f,  1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec3(0.0f,  0.0f, -1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec3(0.0f, -1.0f,  0.0f))
    };

    // pbr: convert HDR equirectangular environment map to cubemap equivalent
    // ----------------------------------------------------------------------
    unsigned int captureFBO;
    unsigned int captureRBO;
    glGenFramebuffers(1, &captureFBO);
    glGenRenderbuffers(1, &captureRBO);
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    glBindRenderbuffer(GL_RENDERBUFFER, captureRBO);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 512, 512);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, captureRBO);

    shader_cubemap->use();
    shader_cubemap->setInt("equirectangularMap", 0);
    shader_cubemap->setMat4("projection", captureProjection);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, hdrTextureID);

    glViewport(0, 0, 512, 512); // don't forget to configure the viewport to the capture dimensions.
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    for (unsigned int i = 0; i < 6; ++i)
    {
        shader_cubemap->setMat4("view", captureViews[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, envCubemap, 0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        renderUnitCube();
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    return envCubemap;
}

GLuint generateIrradianceMap(Shader* shader_irradiance, GLuint envCubemap)
{
    // pbr: create an irradiance cubemap, and re-scale capture FBO to irradiance scale.
    // --------------------------------------------------------------------------------
    unsigned int irradianceMap;
    glGenTextures(1, &irradianceMap);
    glBindTexture(GL_TEXTURE_CUBE_MAP, irradianceMap);
    for (unsigned int i = 0; i < 6; ++i)
    {
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB16F, 32, 32, 0, GL_RGB, GL_FLOAT, nullptr);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // pbr: set up projection and view matrices for capturing data onto the 6 cubemap face directions
    // ----------------------------------------------------------------------------------------------
    glm::mat4 captureProjection = glm::perspective(glm::radians(90.0f), 1.0f, 0.1f, 10.0f);
    glm::mat4 captureViews[] =
    {
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec3(0.0f,  0.0f,  1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec3(0.0f,  0.0f, -1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec3(0.0f, -1.0f,  0.0f))
    };

    // pbr: solve diffuse integral by convolution to create an irradiance (cube)map.
    // -----------------------------------------------------------------------------
    unsigned int captureFBO;
    unsigned int captureRBO;
    glGenFramebuffers(1, &captureFBO);
    glGenRenderbuffers(1, &captureRBO);
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    glBindRenderbuffer(GL_RENDERBUFFER, captureRBO);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 32, 32);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, captureRBO);

    shader_irradiance->use();
    shader_irradiance->setInt("environmentMap", 0);
    shader_irradiance->setMat4("projection", captureProjection);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, envCubemap);

    glViewport(0, 0, 32, 32); // don't forget to configure the viewport to the capture dimensions.
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    for (unsigned int i = 0; i < 6; ++i)
    {
        shader_irradiance->setMat4("view", captureViews[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, irradianceMap, 0);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        renderUnitCube();
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    return irradianceMap;
}

GLuint generatePrefilterMap(Shader* shader_prefilter, GLuint envCubemap)
{
    // pbr: set up projection and view matrices for capturing data onto the 6 cubemap face directions
    // ----------------------------------------------------------------------------------------------
    glm::mat4 captureProjection = glm::perspective(glm::radians(90.0f), 1.0f, 0.1f, 10.0f);
    glm::mat4 captureViews[] =
    {
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec3(0.0f,  0.0f,  1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec3(0.0f,  0.0f, -1.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec3(0.0f, -1.0f,  0.0f)),
        glm::lookAt(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec3(0.0f, -1.0f,  0.0f))
    };

    // pbr: create a pre-filter cubemap, and re-scale capture FBO to pre-filter scale.
    // --------------------------------------------------------------------------------
    unsigned int captureFBO;
    unsigned int captureRBO;
    glGenFramebuffers(1, &captureFBO);
    glGenRenderbuffers(1, &captureRBO);
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);  

    unsigned int prefilterMap;
    glGenTextures(1, &prefilterMap);
    glBindTexture(GL_TEXTURE_CUBE_MAP, prefilterMap);
    for (unsigned int i = 0; i < 6; ++i)
    {
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB16F, 128, 128, 0, GL_RGB, GL_FLOAT, nullptr);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // be sure to set minification filter to mip_linear 
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // generate mipmaps for the cubemap so OpenGL automatically allocates the required memory.
    glGenerateMipmap(GL_TEXTURE_CUBE_MAP);

    // pbr: run a quasi monte-carlo simulation on the environment lighting to create a prefilter (cube)map.
    // ----------------------------------------------------------------------------------------------------
    shader_prefilter->use();
    shader_prefilter->setInt("environmentMap", 0);
    shader_prefilter->setMat4("projection", captureProjection);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, envCubemap);

    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    unsigned int maxMipLevels = 5;
    for (unsigned int mip = 0; mip < maxMipLevels; ++mip)
    {
        // reisze framebuffer according to mip-level size.
        unsigned int mipWidth  = 128 * std::pow(0.5, mip);
        unsigned int mipHeight = 128 * std::pow(0.5, mip);
        glBindRenderbuffer(GL_RENDERBUFFER, captureRBO);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, mipWidth, mipHeight);
        glViewport(0, 0, mipWidth, mipHeight);

        float roughness = (float)mip / (float)(maxMipLevels - 1);
        shader_prefilter->setFloat("roughness", roughness);
        for (unsigned int i = 0; i < 6; ++i)
        {
            shader_prefilter->setMat4("view", captureViews[i]);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, prefilterMap, mip);

            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            renderUnitCube();
        }
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
 
    return prefilterMap;
}

GLuint generateBrdfLUT(Shader* shader_brdf)
{
    // pbr: generate a 2D LUT from the BRDF equations used.
    // ----------------------------------------------------
    unsigned int brdfLUTTexture;
    glGenTextures(1, &brdfLUTTexture);

    // pre-allocate enough memory for the LUT texture.
    glBindTexture(GL_TEXTURE_2D, brdfLUTTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RG16F, 512, 512, 0, GL_RG, GL_FLOAT, 0);
    // be sure to set wrapping mode to GL_CLAMP_TO_EDGE
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // then re-configure capture framebuffer object and render screen-space quad with BRDF shader.
    unsigned int captureFBO;
    unsigned int captureRBO;
    glGenFramebuffers(1, &captureFBO);
    glGenRenderbuffers(1, &captureRBO);
    glBindFramebuffer(GL_FRAMEBUFFER, captureFBO);
    glBindRenderbuffer(GL_RENDERBUFFER, captureRBO);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 512, 512);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, brdfLUTTexture, 0);

    glViewport(0, 0, 512, 512);
    shader_brdf->use();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    renderQuad();

    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    return brdfLUTTexture;
}



void renderFace(GLuint VertexArrayID, GLuint vertexbuffer, GLuint uvbuffer, GLuint EBO, int size)
{
    glBindVertexArray(VertexArrayID);
    // 1rst attribute buffer : vertices
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
    glVertexAttribPointer(
        0,                  // attribute 0. No particular reason for 0, but must match the layout in the shader.
        3,                  // size
        GL_FLOAT,           // type
        GL_FALSE,           // normalized?
        0,                  // stride
        (void*)0            // array buffer offset
    );

    // 2nd attribute buffer : UVs
    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
    glVertexAttribPointer(
        1,                                // attribute. No particular reason for 1, but must match the layout in the shader.
        2,                                // size : U+V => 2
        GL_FLOAT,                         // type
        GL_FALSE,                         // normalized?
        0,                                // stride
        (void*)0                          // array buffer offset
    );

    // Draw !
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glDrawElements(GL_TRIANGLES, size * 6, GL_UNSIGNED_INT, 0);

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
}

glm::vec3 gaussian(float variance, float r, const std::vector<float> &falloff) {
	/**
	* We use a falloff to modulate the shape of the profile. Big falloffs
	* spreads the shape making it wider, while small falloffs make it
	* narrower.
	*/
	glm::vec3 g;
	for (int i = 0; i < 3; i++) {
		float rr = r / (0.001f + falloff[i]);
		g[i] = exp((-(rr * rr)) / (2.0f * variance)) / (2.0f * M_PI * variance);
	}
	return g;
}

glm::vec3 profile(float r, const std::vector<float> &falloff) {
	/**
	* We used the red channel of the original skin profile defined in
	* [d'Eon07] for all three channels. We noticed it can be used for green
	* and blue channels (scaled using the falloff parameter) without
	* introducing noticeable differences and allowing for total control over
	* the profile. For example, it allows to create blue SSS gradients, which
	* could be useful in case of rendering blue creatures.
	*/
	return
		0.100f * gaussian(0.0484f, r, falloff) +
		0.118f * gaussian(0.187f, r, falloff) +
		0.113f * gaussian(0.567f, r, falloff) +
		0.358f * gaussian(1.99f, r, falloff) +
		0.078f * gaussian(7.41f, r, falloff);
}

std::vector<float> ssss_kernel;

void computeSeparableKernel(int num_samples, const glm::vec3 &sss_strength, std::vector<float> &falloff)
{
		//std::vector<glm::vec4> kernel(num_samples);

		const float RANGE = num_samples > 20 ? 3.0f : 2.0f;
		const float EXPONENT = 2.0f;

		ssss_kernel = std::vector<float> (num_samples * 4);

		// Calculate the offsets:
		float step = 2.0f * RANGE / (num_samples - 1);
		//float step = RANGE / (num_samples / 2);
		for (int i = 0; i < num_samples; i++) {
			float o = -RANGE + float(i) * step;
			float sign = o < 0.0f ? -1.0f : 1.0f;
			//_ssss_kernel[i].w = RANGE * sign * abs(pow(o, EXPONENT)) / pow(RANGE, EXPONENT);
			ssss_kernel[i * 4 + 3] = RANGE * sign * abs(pow(o, EXPONENT)) / pow(RANGE, EXPONENT);
		}

		// Calculate the weights:
		for (int i = 0; i < num_samples; i++) {
			//float w0 = i > 0 ? abs(_ssss_kernel[i].w - _ssss_kernel[i - 1].w) : 0.0f;
			//float w1 = i < num_samples - 1 ? abs(_ssss_kernel[i].w - _ssss_kernel[i + 1].w) : 0.0f;
			float w0 = i > 0 ? abs(ssss_kernel[i*4+3] - ssss_kernel[4*(i - 1) +3]) : 0.0f;
			float w1 = i < num_samples - 1 ? abs(ssss_kernel[i * 4 + 3] - ssss_kernel[4*(i + 1)+3]) : 0.0f;
			float area = (w0 + w1) / 2.0f;
			//glm::vec3 t = area * profile(_ssss_kernel[i].w, falloff);
			glm::vec3 t = area * profile(ssss_kernel[i*4+3], falloff);
			ssss_kernel[i*4] = t.x;
			ssss_kernel[i*4 + 1] = t.y;
			ssss_kernel[i*4 + 2] = t.z;
		}

		// We want the offset 0.0 to come first:
		//glm::vec4 t = _ssss_kernel[num_samples / 2];
		glm::vec4 t = glm::vec4(ssss_kernel[(num_samples / 2) * 4], ssss_kernel[(num_samples / 2) * 4 + 1], ssss_kernel[(num_samples / 2) * 4 + 2], ssss_kernel[(num_samples / 2) * 4 + 3]);
		for (int i = num_samples / 2; i > 0; i--)
		{
			ssss_kernel[i*4] = ssss_kernel[(i - 1)*4];
			ssss_kernel[i * 4+1] = ssss_kernel[(i - 1) * 4+1];
			ssss_kernel[i * 4+2] = ssss_kernel[(i - 1) * 4+2];
			ssss_kernel[i * 4+3] = ssss_kernel[(i - 1) * 4+3];
		}
		//_ssss_kernel[0] = t;
		ssss_kernel[0] = t.x;
		ssss_kernel[1] = t.y;
		ssss_kernel[2] = t.z;
		ssss_kernel[3] = t.w;

		// Calculate the sum of the weights, we will need to normalize them below:
		glm::vec3 sum = glm::vec3(0.0f, 0.0f, 0.0f);
		for (int i = 0; i < num_samples; i++)
			//sum += glm::vec3(_ssss_kernel[i]);
			sum += glm::vec3(ssss_kernel[i * 4], ssss_kernel[i * 4 + 1], ssss_kernel[i * 4 + 2]);


		// Normalize the weights:
		for (int i = 0; i < num_samples; i++) {
			//_ssss_kernel[i].x /= sum.x;
			//_ssss_kernel[i].y /= sum.y;
			//_ssss_kernel[i].z /= sum.z;
			ssss_kernel[i*4] /= sum.x;
			ssss_kernel[i*4+1] /= sum.y;
			ssss_kernel[i*4+2] /= sum.z;
		}

		// Tweak them using the desired strength. The first one is:
		//     lerp(1.0, _ssss_kernel[0].rgb, strength)
		//_ssss_kernel[0].x = (1.0f - sss_strength.x) * 1.0f + sss_strength.x * _ssss_kernel[0].x;
		//_ssss_kernel[0].y = (1.0f - sss_strength.y) * 1.0f + sss_strength.y * _ssss_kernel[0].y;
		//_ssss_kernel[0].z = (1.0f - sss_strength.z) * 1.0f + sss_strength.z * _ssss_kernel[0].z;
		ssss_kernel[0] = (1.0f - sss_strength.x) * 1.0f + sss_strength.x * ssss_kernel[1];
		ssss_kernel[1] = (1.0f - sss_strength.y) * 1.0f + sss_strength.y * ssss_kernel[2];
		ssss_kernel[2] = (1.0f - sss_strength.z) * 1.0f + sss_strength.z * ssss_kernel[3];

		// The others:
		//     lerp(0.0, _ssss_kernel[0].rgb, strength)
		for (int i = 1; i < num_samples; i++) {
			//_ssss_kernel[i].x *= sss_strength.x;
			//_ssss_kernel[i].y *= sss_strength.y;
			//_ssss_kernel[i].z *= sss_strength.z;
			ssss_kernel[i*4] *= sss_strength.x;
			ssss_kernel[i*4+1] *= sss_strength.y;
			ssss_kernel[i*4+2] *= sss_strength.z;
		}

}


float lerp(float a, float b, float f)
{
    return a + f * (b - a);
}

const GLenum render_buff[] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2, GL_COLOR_ATTACHMENT3, GL_COLOR_ATTACHMENT4, GL_COLOR_ATTACHMENT5, GL_COLOR_ATTACHMENT6, GL_COLOR_ATTACHMENT7, GL_COLOR_ATTACHMENT8, GL_COLOR_ATTACHMENT9, GL_COLOR_ATTACHMENT10, GL_COLOR_ATTACHMENT11, GL_COLOR_ATTACHMENT12 };
int main()
{
    glewExperimental = true; // Needed for core profile
    if( !glfwInit() )
    {
        fprintf( stderr, "Failed to initialize GLFW\n" );
        return -1;
    }

    glfwWindowHint(GLFW_SAMPLES, 4); // 4x antialiasing
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); // We want OpenGL 3.3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); // We don't want the old OpenGL 

    // Open a window and create its OpenGL context
    window = glfwCreateWindow( 1024, 768, "Geometric Image Viewer", NULL, NULL);
    if( window == NULL ){
        fprintf( stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n" );
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window); 
    
    // Initialize GLEW
    glewExperimental=true; // Needed in core profile
    if (glewInit() != GLEW_OK) {
        fprintf(stderr, "Failed to initialize GLEW\n");
        return -1;
    }

    // Ensure we can capture the escape key being pressed below
    glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
   
    // GLFW callbacks to handle inputs
	glfwSetScrollCallback(window, scroll_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback); 
    
    // Set the mouse at the center of the screen
    glfwPollEvents();
    glfwSetCursorPos(window, 1024/2, 768/2);

	// background
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);
	// Accept fragment if it closer to the camera than the former one
	//glDepthFunc(GL_LESS); 
    glDepthFunc(GL_LEQUAL); // for cubemapping
	// Cull triangles which normal is not towards the camera
	//glEnable(GL_CULL_FACE);
    //glCullFace(GL_BACK); 



    // Load geometric image & other info
    glm::vec3* vertices;
	glm::vec2* uvs;
    unsigned int* indices;
    int size;
    std::string geom_img_dat_file = "./geom_img.dat";
    std::string geom_img_nor_file = "./geom_img.nor";
    std::string geom_img_fine_nor_file = "./geom_img_fine_normal.dat";
    glm::highp_f64vec3 model_center = read_geom_images(geom_img_dat_file, vertices, uvs, indices, size);

    setTarget(model_center + glm::highp_f64vec3(0.0, -50.0, 0.0));


	// Create and compile our GLSL program from the shaders
    // for face main 
    Shader shader_face("shader_face_separate.vert", "shader_face_separate.frag");
    Shader shader_face_wo_ssss("shader_face.vert", "shader_face.frag");
    // for IBL
    Shader shader_cubemap("shader_cubemap.vert", "shader_cubemap.frag");
    Shader shader_irradiance("shader_cubemap.vert", "shader_irradiancemap.frag");
    Shader shader_prefilter("shader_cubemap.vert", "shader_ibl_prefilter.frag");
    Shader shader_brdf("shader_ibl_brdf.vert", "shader_ibl_brdf.frag");
    Shader shader_background("shader_background.vert", "shader_background.frag");
    // for Shadow mapping
    Shader shader_shadowmap("shader_shadowmap.vert", "shader_shadowmap.frag");
    // for Screen space ambient occlusion
    Shader shader_ssao_geometry("shader_ssao_geometry.vert", "shader_ssao_geometry.frag");
    Shader shader_ssao("shader_ssao.vert", "shader_ssao.frag");
    Shader shader_ssao_blur("shader_ssao.vert", "shader_ssao_blur.frag");
    // Subsurface Scattering (SSSS)
    Shader shader_ssss_blur_hor("shader_ssao.vert", "shader_ssss_blur_hor.frag");
    Shader shader_ssss_blur_vert("shader_ssao.vert", "shader_ssss_blur_vert.frag");
    Shader shader_ssss_add_diff_spec("shader_ssao.vert", "shader_add_diffuse_specular.frag");
    // for debugging
    Shader debugQuadColor("shader_debug_quad.vert", "shader_debug_quad.frag");
    Shader debugQuadDepth("shader_debug_quad.vert", "shader_debug_quad_depth.frag");

    shader_background.use();
    shader_background.setInt("environmentMap", 0);
    debugQuadDepth.use();
    debugQuadDepth.setInt("depthMap", 0);
    debugQuadColor.use();
    debugQuadColor.setInt("colorMap", 0);

    int scrWidth, scrHeight;
    glfwGetFramebufferSize(window, &scrWidth, &scrHeight);

    // lights
    const int num_lights = 1;
    // ------ // +x: right of face, +y: below of face, -z: front of face
    glm::vec3 lightTargets[] = {
        glm::vec3(model_center) + glm::vec3(0.0, 10.0, 100.0),  
        glm::vec3(model_center) + glm::vec3(0.0, -50.0, -30.0), 
        glm::vec3(model_center) + glm::vec3(0.0, -50.0, -30.0)     
    };    
    glm::vec3 initialLightPositions[] = {
        glm::vec3(model_center) + glm::vec3( 60.0f,  -60.0f, -200.0f),  // front top
        glm::vec3(model_center) + glm::vec3( -110.0f,  -20.0f, -80.0f), // left lower
        glm::vec3(model_center) + glm::vec3( 110.0f,  -20.0f, -80.0f) // right lower   
    };
    glm::vec3 initialLightDirections[] = {
        glm::normalize(lightTargets[0] - initialLightPositions[0]),  
        glm::normalize(lightTargets[1] - initialLightPositions[1]), 
        glm::normalize(lightTargets[2] - initialLightPositions[2])     
    };
    glm::vec3 initialLightColors[] = {
        glm::vec3(1.0f, 1.0f, 1.0f),
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(0.0f, 0.0f, 1.0f)
    };
    glm::vec3 lightPositions[num_lights];
    glm::vec3 lightDirections[num_lights];
    glm::vec3 lightColors[num_lights];
    for(int i=0; i<num_lights; i++){
        lightPositions[i] = initialLightPositions[i];
        lightDirections[i] = initialLightDirections[i];
        lightColors[i] = initialLightColors[i];
    }

    bool lightCastShadow[] = {true, false, false};

    //
    // Screen Space Ambient Occlusion (SSAO)
    //

    // configure g-buffer framebuffer
    // ------------------------------
    unsigned int gBuffer;
    glGenFramebuffers(1, &gBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, gBuffer);
    unsigned int gPosition, gNormal, gAlbedo;
    // position color buffer
    glGenTextures(1, &gPosition);
    glBindTexture(GL_TEXTURE_2D, gPosition);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, scrWidth, scrHeight, 0, GL_RGBA, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gPosition, 0);
    // normal color buffer
    glGenTextures(1, &gNormal);
    glBindTexture(GL_TEXTURE_2D, gNormal);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, scrWidth, scrHeight, 0, GL_RGBA, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, gNormal, 0);
    // color + specular color buffer
    glGenTextures(1, &gAlbedo);
    glBindTexture(GL_TEXTURE_2D, gAlbedo);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT2, GL_TEXTURE_2D, gAlbedo, 0);
    // tell OpenGL which color attachments we'll use (of this framebuffer) for rendering 
    unsigned int attachments[3] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2 };
    glDrawBuffers(3, attachments);
    // create and attach depth buffer (renderbuffer)
    unsigned int rboDepth;
    glGenRenderbuffers(1, &rboDepth);
    glBindRenderbuffer(GL_RENDERBUFFER, rboDepth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, scrWidth, scrHeight);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rboDepth);
    // finally check if framebuffer is complete
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        std::cout << "Framebuffer not complete!" << std::endl;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // also create framebuffer to hold SSAO processing stage 
    // -----------------------------------------------------
    unsigned int ssaoFBO, ssaoBlurFBO;
    glGenFramebuffers(1, &ssaoFBO);  glGenFramebuffers(1, &ssaoBlurFBO);
    glBindFramebuffer(GL_FRAMEBUFFER, ssaoFBO);
    unsigned int ssaoColorBuffer, ssaoColorBufferBlur;
    // SSAO color buffer
    glGenTextures(1, &ssaoColorBuffer);
    glBindTexture(GL_TEXTURE_2D, ssaoColorBuffer);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, scrWidth, scrHeight, 0, GL_RED, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ssaoColorBuffer, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        std::cout << "SSAO Framebuffer not complete!" << std::endl;
    // and blur stage
    glBindFramebuffer(GL_FRAMEBUFFER, ssaoBlurFBO);
    glGenTextures(1, &ssaoColorBufferBlur);
    glBindTexture(GL_TEXTURE_2D, ssaoColorBufferBlur);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, scrWidth, scrHeight, 0, GL_RED, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ssaoColorBufferBlur, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        std::cout << "SSAO Blur Framebuffer not complete!" << std::endl;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // generate sample kernel
    // ----------------------
    std::uniform_real_distribution<GLfloat> randomFloats(0.0, 1.0); // generates random floats between 0.0 and 1.0
    std::default_random_engine generator;
    std::vector<glm::vec3> ssaoKernel;
    for (unsigned int i = 0; i < 64; ++i)
    {
        glm::vec3 sample(randomFloats(generator) * 2.0 - 1.0, randomFloats(generator) * 2.0 - 1.0, randomFloats(generator));
        sample = glm::normalize(sample);
        sample *= randomFloats(generator);
        float scale = float(i) / 64.0;

        // scale samples s.t. they're more aligned to center of kernel
        scale = lerp(0.1f, 1.0f, scale * scale);
        sample *= scale;
        ssaoKernel.push_back(sample);
    }

    // generate noise texture
    // ----------------------
    std::vector<glm::vec3> ssaoNoise;
    for (unsigned int i = 0; i < 16; i++)
    {
        glm::vec3 noise(randomFloats(generator) * 2.0 - 1.0, randomFloats(generator) * 2.0 - 1.0, 0.0f); // rotate around z-axis (in tangent space)
        ssaoNoise.push_back(noise);
    }
    unsigned int noiseTexture; glGenTextures(1, &noiseTexture);
    glBindTexture(GL_TEXTURE_2D, noiseTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, 4, 4, 0, GL_RGB, GL_FLOAT, &ssaoNoise[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    shader_ssao.use();
    shader_ssao.setInt("gPosition", 0);
    shader_ssao.setInt("gNormal", 1);
    shader_ssao.setInt("texNoise", 2);
    shader_ssao_blur.use();
    shader_ssao_blur.setInt("ssaoInput", 0);


    //
    // Shadow mapping
    //

    // Prepare shadowmap generation
    const unsigned int SHADOW_WIDTH = 1024, SHADOW_HEIGHT = 1024;
    GLuint shadowMapFBO[num_lights];
 
    // create depth texture
    GLuint shadowMap[num_lights];
    for(int i=0; i<num_lights; i++){
        glGenFramebuffers(1, &shadowMapFBO[i]);
        glGenTextures(1, &shadowMap[i]);
        glBindTexture(GL_TEXTURE_2D, shadowMap[i]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, SHADOW_WIDTH, SHADOW_HEIGHT, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        float borderColor[] = { 1.0, 1.0, 1.0, 1.0 };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);
        // attach depth texture as FBO's depth buffer
        glBindFramebuffer(GL_FRAMEBUFFER, shadowMapFBO[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowMap[i], 0);
        glDrawBuffer(GL_NONE);
        glReadBuffer(GL_NONE);
        glBindFramebuffer(GL_FRAMEBUFFER, 0); 
    }




    //
    // Image Based Lighting (IBL)
    //
    GLuint hdrTextureID = loadHDRImage("./HDR/Newport_Loft_Ref.hdr"); //"glass_passage_2k.hdr" "surgery_2k.hdr" "Alexs_Apt_2k.hdr" "small_cathedral_2k.hdr"
    // Generate a Cubemap from an equirectangular HDR image
    GLuint envCubemap = generateCubemap(&shader_cubemap, hdrTextureID);
    // Generate an Irradiance map from the cubemap
    GLuint irradiancemap = generateIrradianceMap(&shader_irradiance, envCubemap);
    // Generate a prefiltered map for specular IBL
    GLuint prefiltermap = generatePrefilterMap(&shader_prefilter, envCubemap);  
    // Generate a 2D LUT from the BRDF equations used
    GLuint brdfLUTTexture = generateBrdfLUT(&shader_brdf);


    //
    // Face 
    //
    // Load the texture 
    GLuint TextureID = loadImage("blended_texture.bmp");
    // Load the normap map as a texture 
    GLuint TextureID_Norm = load_NormalColor(geom_img_nor_file);
    GLuint TextureID_FineNorm = load_NormalColor(geom_img_fine_nor_file);
    
    shader_face.use();
    // VAO
    GLuint VertexArrayID;
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);
    // Load it into a VBO
    GLuint vertexbuffer;
    glGenBuffers(1, &vertexbuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
    glBufferData(GL_ARRAY_BUFFER, size * sizeof(glm::vec3), &vertices[0], GL_STATIC_DRAW);
    GLuint uvbuffer;
    glGenBuffers(1, &uvbuffer);
    glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
    glBufferData(GL_ARRAY_BUFFER, size * sizeof(glm::vec2), &uvs[0], GL_STATIC_DRAW);
    // element array
    GLuint EBO;
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, size * 6 * sizeof(unsigned int), indices, GL_STATIC_DRAW);

    // configure a framebuffer for face rendering
    // ------------------------------
    unsigned int faceFBO;
    unsigned int faceRBO;
    glGenFramebuffers(1, &faceFBO);
    glGenRenderbuffers(1, &faceRBO);
    glBindFramebuffer(GL_FRAMEBUFFER, faceFBO);
    glBindRenderbuffer(GL_RENDERBUFFER, faceRBO);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, scrWidth, scrHeight);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, faceRBO);

    unsigned int faceColor, faceAlbedo, faceSpecular, faceDepth;
    // color buffer
    glGenTextures(1, &faceColor);
    glBindTexture(GL_TEXTURE_2D, faceColor);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST); 
    // albedo buffer
    glGenTextures(1, &faceAlbedo);
    glBindTexture(GL_TEXTURE_2D, faceAlbedo);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST); 
    // specular buffer
    glGenTextures(1, &faceSpecular);
    glBindTexture(GL_TEXTURE_2D, faceSpecular);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    // depth buffer
    glGenTextures(1, &faceDepth);
    glBindTexture(GL_TEXTURE_2D, faceDepth);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH24_STENCIL8, scrWidth, scrHeight, 0, GL_DEPTH_STENCIL, GL_UNSIGNED_INT_24_8, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
    float borderColor[] = { 1.0, 1.0, 1.0, 1.0 };
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);    
     

    //
    // Separable Screen Space Subsurface Scattering (SSSS)
    //

    int num_sss_samples = 20;
	glm::vec3 sss_strength = glm::vec3(0.48, 0.41, 0.28);
	std::vector<float> falloff = {1.0f, 0.37f, 0.3f};
    float sss_width = 0.005 * 0.5; //0.012; //0.005 * 0.5;// *0.9; // 0.012 is the default value used in DX demo

    computeSeparableKernel(num_sss_samples, sss_strength, falloff);

    // horizontally blurred color buffer
    unsigned int ssssHorizontal;
    glGenTextures(1, &ssssHorizontal);
    glBindTexture(GL_TEXTURE_2D, ssssHorizontal);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // vertically blurred color buffer
    unsigned int ssssVertical;
    glGenTextures(1, &ssssVertical);
    glBindTexture(GL_TEXTURE_2D, ssssVertical);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // prepare to merge blurred diffuse and specular
    unsigned int ssssMerged;
    glGenTextures(1, &ssssMerged);
    glBindTexture(GL_TEXTURE_2D, ssssMerged);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // prepare the final render
    unsigned int finalTexture;
    glGenTextures(1, &finalTexture);
    glBindTexture(GL_TEXTURE_2D, finalTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, scrWidth, scrHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
 
    glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
    
    // before rendering, configure the viewport to the original framebuffer's screen dimensions
    glViewport(0, 0, scrWidth, scrHeight);

    // render loop
    do{
        // Clear the screen. 
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // let's move the main light with arrow keys
        glm::vec3 lightMoved = getLightRot(); // x, y: rotated value in each axis, z: intensity
        float horizAngle = glm::radians(lightMoved.x);
        float vertAngle = glm::radians(lightMoved.y);
        glm::mat3x3 rotmat_y(cos(horizAngle), 0.0, sin(horizAngle), 0.0, 1.0, 0.0, -sin(horizAngle), 0.0, cos(horizAngle));
        glm::mat3x3 rotmat_x(1.0, 0.0, 0.0, 0.0, cos(vertAngle), -sin(vertAngle), 0.0, sin(vertAngle), cos(vertAngle));
        glm::mat3x3 rotmat = rotmat_x * rotmat_y;
        lightPositions[0] = rotmat * (initialLightPositions[0] - lightTargets[0]) + lightTargets[0];
        //lightPositions[0] = initialLightPositions[0] + lightMoved;
        lightDirections[0] = lightTargets[0] - lightPositions[0];
        float intensityx = lightMoved[2];
        lightColors[0] = initialLightColors[0] * intensityx;
        
        // Compute the MVP matrix from keyboard and mouse input
        computeMatricesFromInputs();
        glm::mat4 matProjection = getProjectionMatrix();
        glm::mat4 matView = getViewMatrix();
        glm::mat4 matModel = glm::mat4(1.0);
        glm::mat4 matMVP = matProjection * matView * matModel;
        glm::vec3 cam_pos = getCameraPosition();

        float exposure = getExposure();

        // SSAO
        //

        // 1. geometry pass: render scene's geometry/color data into gbuffer
        // -----------------------------------------------------------------
        glBindFramebuffer(GL_FRAMEBUFFER, gBuffer);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            shader_ssao_geometry.use();
            shader_ssao_geometry.setMat4("projection", matProjection);
            shader_ssao_geometry.setMat4("view", matView);
            shader_ssao_geometry.setMat4("model", matModel);
            int normal_mode = getNormalDisplayMode();
            if(normal_mode == 0)
                shader_ssao_geometry.setInt("modeNormal", 0); // surface normal
            else if(normal_mode ==1)
                shader_ssao_geometry.setInt("modeNormal", 1); // fine normal                
            // Bind our textures
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, TextureID_Norm);
            shader_ssao_geometry.setInt("myNormalSampler", 0);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, TextureID_FineNorm);
            shader_ssao_geometry.setInt("myFineNormalSampler", 1);

            renderFace(VertexArrayID, vertexbuffer,uvbuffer, EBO, size);
            //renderSphere(10.0, lightPositions[0] + vec3(0.0, 20.0, 120.0));
        glBindFramebuffer(GL_FRAMEBUFFER, 0);


        // 2. generate SSAO texture
        // ------------------------
        glBindFramebuffer(GL_FRAMEBUFFER, ssaoFBO);
            glClear(GL_COLOR_BUFFER_BIT);
            shader_ssao.use();
            // Send kernel + rotation 
            for (unsigned int i = 0; i < 64; ++i)
                shader_ssao.setVec3("samples[" + std::to_string(i) + "]", ssaoKernel[i]);
            shader_ssao.setMat4("projection", matProjection);
            shader_ssao.setFloat("scrWidth", scrWidth);
            shader_ssao.setFloat("scrHeight", scrHeight);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, gPosition);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, gNormal);
            glActiveTexture(GL_TEXTURE2);
            glBindTexture(GL_TEXTURE_2D, noiseTexture);
            renderQuad();
        glBindFramebuffer(GL_FRAMEBUFFER, 0);


        // 3. blur SSAO texture to remove noise
        // ------------------------------------
        glBindFramebuffer(GL_FRAMEBUFFER, ssaoBlurFBO);
            glClear(GL_COLOR_BUFFER_BIT);
            shader_ssao_blur.use();
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, ssaoColorBuffer);
            renderQuad();
        glBindFramebuffer(GL_FRAMEBUFFER, 0);


        // Generate shadowmaps
        // render depth of scene to texture (from light's perspective)
        // --------------------------------------------------------------
        glm::mat4 lightSpaceMatrix[num_lights];

        float near_plane = 1.0f, far_plane = 1000.0f;        
        bool useLight = getUseExtraLights();
        if(useLight){
            for(int i=0; i<num_lights; i++){
                //glm::mat4 lightProjection = glm::perspective<float>(glm::radians(lightOuterCutoffAngle[i]*2), (GLfloat)SHADOW_WIDTH / (GLfloat)SHADOW_HEIGHT, near_plane, far_plane); 
                glm::mat4 lightProjection = glm::ortho(-200.0f, 200.0f, -200.0f, 200.0f, near_plane, far_plane);
                glm::mat4 lightView = glm::lookAt(lightPositions[i], lightPositions[i]+lightDirections[i], glm::vec3(0.0, 1.0, 0.0));
                lightSpaceMatrix[i] = lightProjection * lightView;
                
                if(lightCastShadow[i]){
                    // render scene from light's point of view
                    shader_shadowmap.use();
                    shader_shadowmap.setMat4("lightSpaceMatrix", lightSpaceMatrix[i]);
                    glm::mat4 model = glm::mat4(1.0f);
                    shader_shadowmap.setMat4("model", model);

                    glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
                    glBindFramebuffer(GL_FRAMEBUFFER, shadowMapFBO[i]);
                        glClear(GL_DEPTH_BUFFER_BIT);
                        renderFace(VertexArrayID, vertexbuffer,uvbuffer, EBO, size);                   
                    glBindFramebuffer(GL_FRAMEBUFFER, 0);
                }
            }
        }


        // reset viewport
        glViewport(0, 0, scrWidth, scrHeight);

        bool useSSSS = getSSSSMode();
        if(useSSSS){ // rendering face with screen space subsurface scattering
            glEnable(GL_STENCIL_TEST);
            glStencilFunc(GL_ALWAYS, 1, 0xFF);
            glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
            glStencilMask(0xFF);
            
            //
            // Draw Face mesh
            //
            glBindFramebuffer(GL_FRAMEBUFFER, faceFBO);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, faceColor, 0);    
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, faceAlbedo, 0);      
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT2, GL_TEXTURE_2D, faceSpecular, 0);          
                // tell OpenGL which color attachments we'll use (of this framebuffer) for rendering 
                unsigned int face_attachments[3] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2 };
                glDrawBuffers(3, face_attachments);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_TEXTURE_2D, faceDepth, 0);

                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);


                // set a current shader program
                shader_face.use();

                // Send our transformation to the currently bound shader, 
                // in the "MVP" uniform
                shader_face.setMat4("MVP", matMVP);
                shader_face.setMat4("M", matModel);
                shader_face.setMat4("V", matView);
                shader_face.setVec3("camPos", cam_pos);

                // setting the materials
                shader_face.setVec3("material.albedo", glm::vec3(0.5f, 0.5f, 0.5f));
                shader_face.setFloat("material.ao", 1.0f);
                shader_face.setFloat("material.metallic", 0.0);
                shader_face.setFloat("material.roughness", 0.6);

                shader_face.setFloat("exposure", exposure);

                shader_face.setBool("useLight", useLight);
                if(useLight){
                // setting point lights
                    for (unsigned int i = 0; i < num_lights; ++i)
                    {
                        shader_face.setVec3("lights[" + std::to_string(i) + "].position", lightPositions[i]);
                        shader_face.setVec3("lights[" + std::to_string(i) + "].direction", lightDirections[i]);
                        shader_face.setVec3("lights[" + std::to_string(i) + "].color", lightColors[i]);
                        // shadow matrix
                        shader_face.setMat4("lights[" + std::to_string(i) + "].matrix", lightSpaceMatrix[i]);
                        shader_face.setBool("lights[" + std::to_string(i) + "].castshadow", lightCastShadow[i]);
                    }
                }

                // setting the textures mode
                int textureMode = getTextureMode();
                if(textureMode==0)
                    shader_face.setInt("modeTexture", 0);
                else if(textureMode==1)
                    shader_face.setInt("modeTexture", 1);
                else if(textureMode==2)
                    shader_face.setInt("modeTexture", 2);
                else if(textureMode==3)
                    shader_face.setInt("modeTexture", 3);    

                // Bind textures
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, TextureID);
                shader_face.setInt("myTextureSampler", 0);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, TextureID_Norm);
                shader_face.setInt("myNormalSampler", 1);
                glActiveTexture(GL_TEXTURE2);
                glBindTexture(GL_TEXTURE_2D, TextureID_FineNorm);
                shader_face.setInt("myFineNormalSampler", 2);     
                // bind pre-computed IBL data
                glActiveTexture(GL_TEXTURE3);
                glBindTexture(GL_TEXTURE_CUBE_MAP, irradiancemap);
                shader_face.setInt("irradianceMap", 3);     
                glActiveTexture(GL_TEXTURE4);
                glBindTexture(GL_TEXTURE_CUBE_MAP, prefiltermap);
                shader_face.setInt("prefilterMap", 4);    
                glActiveTexture(GL_TEXTURE5);
                glBindTexture(GL_TEXTURE_2D, brdfLUTTexture);
                shader_face.setInt("brdfLUT", 5);  
                // bind ssao texture
                glActiveTexture(GL_TEXTURE6); // add extra SSAO texture to lighting pass
                glBindTexture(GL_TEXTURE_2D, ssaoColorBufferBlur);
                shader_face.setInt("ssaoSampler", 6); 
                // bind shadowmap textures
                if(useLight){
                    for(int i=0; i<num_lights; i++){
                        glActiveTexture(GL_TEXTURE7 + i);
                        glBindTexture(GL_TEXTURE_2D, shadowMap[i]);
                        shader_face.setInt("shadowSampler[0]", i+7);
                    }        
                }

                // setting the normal mode
                normal_mode = getNormalDisplayMode();
                if(normal_mode == 0)
                    shader_face.setInt("modeNormal", 0); // surface normal
                else if(normal_mode ==1)
                    shader_face.setInt("modeNormal", 1); // fine normal                
                
                renderFace(VertexArrayID, vertexbuffer,uvbuffer, EBO, size);
                glDisable(GL_STENCIL_TEST);
            glBindFramebuffer(GL_FRAMEBUFFER, 0);

            // 
            // Subsurface Scattering w/ Face render images
            //
            glDisable(GL_DEPTH_TEST);
            glDepthMask(GL_FALSE);
            glEnable(GL_STENCIL_TEST);
            glStencilFunc(GL_EQUAL, 1, 0xFF);
            glStencilMask(0x00);

            // horizontal pass
            glBindFramebuffer(GL_FRAMEBUFFER, faceFBO); 
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_TEXTURE_2D, faceDepth, 0);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ssssHorizontal, 0);    
                glDrawBuffers(1, render_buff);
                
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                
                shader_ssss_blur_hor.use();
                // Bind textures
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, faceColor);
                shader_ssss_blur_hor.setInt("color_texture", 0);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, faceDepth);
                shader_ssss_blur_hor.setInt("depth_texture", 1);
                glActiveTexture(GL_TEXTURE2);
                glBindTexture(GL_TEXTURE_2D, faceAlbedo);
                shader_ssss_blur_hor.setInt("albedo_texture", 2);

                shader_ssss_blur_hor.setFloat("cam_fovy", glm::radians(getFov()));
                shader_ssss_blur_hor.setFloat("correction", 300.0);
                shader_ssss_blur_hor.setFloat("sssWidth", sss_width);
                shader_ssss_blur_hor.setFloat("kernel_range", 3.0);
                shader_ssss_blur_hor.setInt("ssss_n_samples", num_sss_samples);
                shader_ssss_blur_hor.setFloat("near_plane", 10.0); // should be same with camera's near/far planes
                shader_ssss_blur_hor.setFloat("far_plane", 1500.0);
                shader_ssss_blur_hor.setBool("checkSkinColor", true);
                glUniform4fv(glGetUniformLocation(shader_ssss_blur_hor.ID, "kernel"), num_sss_samples * 4, ssss_kernel.data());

                renderQuad();
            glBindFramebuffer(GL_FRAMEBUFFER, 0);

            // vertical pass
            glBindFramebuffer(GL_FRAMEBUFFER, faceFBO); 
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_TEXTURE_2D, faceDepth, 0);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ssssVertical, 0);    
                glDrawBuffers(1, render_buff);

                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

                shader_ssss_blur_vert.use();
                // Bind textures
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, ssssHorizontal);
                shader_ssss_blur_vert.setInt("color_texture", 0);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, faceDepth);
                shader_ssss_blur_vert.setInt("depth_texture", 1);
                glActiveTexture(GL_TEXTURE2);
                glBindTexture(GL_TEXTURE_2D, faceAlbedo);
                shader_ssss_blur_vert.setInt("albedo_texture", 2);
                shader_ssss_blur_vert.setFloat("cam_fovy", glm::radians(getFov()));
                shader_ssss_blur_vert.setFloat("correction", 300.0);
                shader_ssss_blur_vert.setFloat("sssWidth", sss_width);
                shader_ssss_blur_vert.setFloat("kernel_range", 3.0);
                shader_ssss_blur_vert.setInt("ssss_n_samples", num_sss_samples);
                shader_ssss_blur_vert.setFloat("near_plane", 10.0); // should be same with camera's near/far planes
                shader_ssss_blur_vert.setFloat("far_plane", 1500.0);
                shader_ssss_blur_vert.setBool("checkSkinColor", true);
                glUniform4fv(glGetUniformLocation(shader_ssss_blur_vert.ID, "kernel"), num_sss_samples * 4, ssss_kernel.data());

                renderQuad();
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            
            glEnable(GL_DEPTH_TEST);
            glDepthMask(GL_TRUE);
            glDisable(GL_STENCIL_TEST);

            // merge blurred diffuse and specular to get the final face
            glBindFramebuffer(GL_FRAMEBUFFER, faceFBO); 
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_TEXTURE_2D, faceDepth, 0);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, ssssMerged, 0);    
                glDrawBuffers(1, render_buff);

                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

                shader_ssss_add_diff_spec.use();
                shader_ssss_add_diff_spec.setFloat("exposure", exposure);
                // Bind textures
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, ssssVertical);
                shader_ssss_add_diff_spec.setInt("diffuseMap", 0);
                glActiveTexture(GL_TEXTURE1);
                glBindTexture(GL_TEXTURE_2D, faceSpecular);
                shader_ssss_add_diff_spec.setInt("specularMap", 1);

                renderQuad();
            glBindFramebuffer(GL_FRAMEBUFFER, 0);

            /*
            // debug 
            if(0){ // color 
                glViewport(0, 0, scrWidth, scrHeight);
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                debugQuadColor.use();
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, ssssMerged);
                debugQuadColor.setInt("colorMap", 0);  
                renderQuad();
            }
            if(0){ // depth
                glViewport(0, 0, scrWidth, scrHeight);
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                debugQuadDepth.use();
                debugQuadDepth.setFloat("near_plane", 10.0); //use the values used by the cam (defined in control.cpp)
                debugQuadDepth.setFloat("far_plane", 1000.0);
                debugQuadDepth.setBool("isDepth", true);
                debugQuadDepth.setBool("isPerspective", true);
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, faceDepth);
                renderQuad();
            }
            */

            glBindFramebuffer(GL_FRAMEBUFFER, faceFBO); //finalFBO);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_TEXTURE_2D, faceDepth, 0);
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, finalTexture, 0);    
                glDrawBuffers(1, render_buff);

                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

                glEnable(GL_STENCIL_TEST);
                glStencilFunc(GL_EQUAL, 0, 0xFF);
                glStencilMask(0x00);
                //
                // Draw backgrounds (cubemap)
                //
                int envmode = getEnvmapMode();
                if(envmode < 2){
                    shader_background.use();
                    shader_background.setMat4("view", matView);
                    shader_background.setMat4("projection", matProjection);
                    shader_background.setFloat("exposure", exposure);
                    glActiveTexture(GL_TEXTURE0);
                    if(envmode == 0)
                        glBindTexture(GL_TEXTURE_CUBE_MAP, envCubemap);
                    else
                        glBindTexture(GL_TEXTURE_CUBE_MAP, irradiancemap); /// blurred version
                    renderUnitCube();
                }

                glStencilFunc(GL_EQUAL, 1, 0xFF);
                glStencilMask(0x00); 
                //       
                // draw foregrounds (final face)
                //
                debugQuadColor.use();
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, ssssMerged);
                debugQuadColor.setInt("colorMap", 0);  
                debugQuadColor.setFloat("exposure", exposure);
                renderQuad();
                glDisable(GL_STENCIL_TEST);
            glBindFramebuffer(GL_FRAMEBUFFER, 0);


            //
            // Draw final result on the screen
            debugQuadColor.use();
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, finalTexture);
            debugQuadColor.setInt("colorMap", 0);  
            debugQuadColor.setFloat("exposure", exposure);
            renderQuad();

             /*
            //
            // Draw spheres at the light positions
            //
            if(1 && useLight){
                for (unsigned int i = 0; i < sizeof(lightPositions) / sizeof(lightPositions[0]); ++i)
                {
                    renderSphere(5.0, lightPositions[i]);
                }
            }
            */
        }
        else{ // rendering face without screen space subsurface scattering
           
            //
            // Draw Face mesh
            //
            glBindFramebuffer(GL_FRAMEBUFFER, 0);

            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

            // set a current shader program
            shader_face_wo_ssss.use();

            // Send our transformation to the currently bound shader, 
            // in the "MVP" uniform
            shader_face_wo_ssss.setMat4("MVP", matMVP);
            shader_face_wo_ssss.setMat4("M", matModel);
            shader_face_wo_ssss.setMat4("V", matView);
            shader_face_wo_ssss.setVec3("camPos", cam_pos);

            // setting the materials
            shader_face_wo_ssss.setVec3("material.albedo", glm::vec3(0.7f, 0.7f, 0.7f));
            shader_face_wo_ssss.setFloat("material.ao", 1.0f);
            shader_face_wo_ssss.setFloat("material.metallic", 0.0);
            shader_face_wo_ssss.setFloat("material.roughness", 0.7);

            shader_face_wo_ssss.setFloat("exposure", exposure);

            shader_face_wo_ssss.setBool("useLight", useLight);
            if(useLight){
            // setting point lights
                for (unsigned int i = 0; i < num_lights; ++i)
                {
                    shader_face_wo_ssss.setVec3("lights[" + std::to_string(i) + "].position", lightPositions[i]);
                    shader_face_wo_ssss.setVec3("lights[" + std::to_string(i) + "].direction", lightDirections[i]);
                    shader_face_wo_ssss.setVec3("lights[" + std::to_string(i) + "].color", lightColors[i]);
                    //shader_face_wo_ssss.setFloat("lights[" + std::to_string(i) + "].cutoff", lightCutoff[i]);
                    //shader_face_wo_ssss.setFloat("lights[" + std::to_string(i) + "].outerCutoff", lightOuterCutoff[i]);
                    //shader_face_wo_ssss.setFloat("lights[" + std::to_string(i) + "].constant", lightConstant);
                    //shader_face_wo_ssss.setFloat("lights[" + std::to_string(i) + "].linear", lightLinear);
                    //shader_face_wo_ssss.setFloat("lights[" + std::to_string(i) + "].quadratic", lightQuadratic);

                    // shadow matrix
                    shader_face_wo_ssss.setMat4("lights[" + std::to_string(i) + "].matrix", lightSpaceMatrix[i]);
                    shader_face_wo_ssss.setBool("lights[" + std::to_string(i) + "].castshadow", lightCastShadow[i]);
                }
            }

            // setting the textures mode
            int textureMode = getTextureMode();
            if(textureMode==0)
                shader_face_wo_ssss.setInt("modeTexture", 0);
            else if(textureMode==1)
                shader_face_wo_ssss.setInt("modeTexture", 1);
            else if(textureMode==2)
                shader_face_wo_ssss.setInt("modeTexture", 2);
            else if(textureMode==3)
                shader_face_wo_ssss.setInt("modeTexture", 3);    

            // Bind textures
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, TextureID);
            shader_face_wo_ssss.setInt("myTextureSampler", 0);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, TextureID_Norm);
            shader_face_wo_ssss.setInt("myNormalSampler", 1);
            glActiveTexture(GL_TEXTURE2);
            glBindTexture(GL_TEXTURE_2D, TextureID_FineNorm);
            shader_face_wo_ssss.setInt("myFineNormalSampler", 2);     
            // bind pre-computed IBL data
            glActiveTexture(GL_TEXTURE3);
            glBindTexture(GL_TEXTURE_CUBE_MAP, irradiancemap);
            shader_face_wo_ssss.setInt("irradianceMap", 3);     
            glActiveTexture(GL_TEXTURE4);
            glBindTexture(GL_TEXTURE_CUBE_MAP, prefiltermap);
            shader_face_wo_ssss.setInt("prefilterMap", 4);    
            glActiveTexture(GL_TEXTURE5);
            glBindTexture(GL_TEXTURE_2D, brdfLUTTexture);
            shader_face_wo_ssss.setInt("brdfLUT", 5);  
            // bind ssao texture
            glActiveTexture(GL_TEXTURE6); // add extra SSAO texture to lighting pass
            glBindTexture(GL_TEXTURE_2D, ssaoColorBufferBlur);
            shader_face_wo_ssss.setInt("ssaoSampler", 6); 
            // bind shadowmap textures
            if(useLight){
                for(int i=0; i<num_lights; i++){
                    glActiveTexture(GL_TEXTURE7 + i);
                    glBindTexture(GL_TEXTURE_2D, shadowMap[i]);
                    shader_face_wo_ssss.setInt("shadowSampler[0]", i+7);
                }        
            }

            // setting the normal mode
            normal_mode = getNormalDisplayMode();
            if(normal_mode == 0)
                shader_face_wo_ssss.setInt("modeNormal", 0); // surface normal
            else if(normal_mode ==1)
                shader_face_wo_ssss.setInt("modeNormal", 1); // fine normal                
            
            renderFace(VertexArrayID, vertexbuffer,uvbuffer, EBO, size);




            // Draw backgrounds (cubemap)
            //
            int envmode = getEnvmapMode();
            if(envmode < 2){
                shader_background.use();
                shader_background.setMat4("view", matView);
                shader_background.setMat4("projection", matProjection);
                shader_background.setFloat("exposure", exposure);
                glActiveTexture(GL_TEXTURE0);
                if(envmode == 0)
                    glBindTexture(GL_TEXTURE_CUBE_MAP, envCubemap);
                else
                    glBindTexture(GL_TEXTURE_CUBE_MAP, irradiancemap); /// blurred version
                renderUnitCube();
            }
          
            //
            // Draw spheres at the light positions
            //
            if(1 && useLight){
                for (unsigned int i = 0; i < sizeof(lightPositions) / sizeof(lightPositions[0]); ++i)
                {
                    renderSphere(5.0, lightPositions[i]);
                }
            }
        }

        // Swap buffers
        glfwSwapBuffers(window);
        glfwPollEvents();

    } // Check if the ESC key was pressed or the window was closed
    while( glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS && glfwWindowShouldClose(window) == 0 );

	// Cleanup VBO and shader
	glDeleteBuffers(1, &vertexbuffer);
	glDeleteBuffers(1, &uvbuffer);

	glDeleteTextures(1, &TextureID);
    glDeleteTextures(1, &TextureID_Norm);
    glDeleteTextures(1, &TextureID_FineNorm);
	glDeleteVertexArrays(1, &VertexArrayID);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;    
}