// Include GLFW
#include <GLFW/glfw3.h>
extern GLFWwindow* window; 

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;

#include "controls.h"

glm::mat4 ViewMatrix;
glm::mat4 ProjectionMatrix;

glm::mat4 getViewMatrix(){
	return ViewMatrix;
}
glm::mat4 getProjectionMatrix(){
	return ProjectionMatrix;
}

float initialRadius = 300.;
float currentRadius = 300.;

int normalMode = 0; // 0 : normal, 1: fine normal;
int textureMode = 0; //0: no texture, 1: texture, 2: normal color
bool useSSSS = true; 
int envMode = 0; // 0 : cubemap, 1: irrandiance map, 2: black
bool useLight = false;

float exposure = 2.0;

// light control
glm::vec3 lightRotMove = glm::vec3(0.0, 0.0, 1.0); // rot in x, t & light intensity multiplier

// Initial position : on +Z
glm::vec3 position = glm::vec3( 0, 0, initialRadius ); 
glm::vec3 target = glm::vec3( 0.0, 0.0, 0.0);
// Initial horizontal angle : toward -Z
float horizontalAngle = 0.0f;//3.14f;
// Initial vertical angle : upside down
float verticalAngle = 0.0f;
// Initial Field of View
float initialFoV = 30.0f;


float speed = 100.0f; // 2 units / second
float mouseSpeed = 0.005f;


float getFov()
{
	return initialFoV;
}

int getTextureMode()
{
	return textureMode;
}

bool getSSSSMode()
{
	return useSSSS;
}

int getNormalDisplayMode()
{
	return normalMode;
}

glm::vec3 getCameraPosition()
{
	return position;
}

int getEnvmapMode()
{
	return envMode;
}

bool getUseExtraLights()
{
	return useLight;
}

glm::vec3 getLightRot()
{
	return lightRotMove;
}

float getExposure()
{
	return exposure;
}

void setTarget(glm::highp_f64vec3 obj_target)
{
	target.x = (glm::f32)obj_target.x;
	target.y = (glm::f32)obj_target.y;
	target.z = (glm::f32)obj_target.z;
}


void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	currentRadius += yoffset * 100;
}


double prev_xpos, prev_ypos;
bool isMousePressed = false;
double prev_R_xpos, prev_R_ypos;
bool isRMousePressed = false;

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT) {
        if(action == GLFW_PRESS){
            isMousePressed = true;
			glfwGetCursorPos(window, &prev_xpos, &prev_ypos);
		
		}
        else if(action == GLFW_RELEASE)
            isMousePressed = false;		
    }
	else if(button == GLFW_MOUSE_BUTTON_RIGHT){
        if(action == GLFW_PRESS){
            isRMousePressed = true;
			glfwGetCursorPos(window, &prev_R_xpos, &prev_R_ypos);
		
		}
        else if(action == GLFW_RELEASE)
            isRMousePressed = false;			
	}
}

void computeMatricesFromInputs()
{

    if(isMousePressed) {
		double xpos, ypos;
		glfwGetCursorPos(window, &xpos, &ypos);

		horizontalAngle += mouseSpeed * float(prev_xpos - xpos );
		verticalAngle   -= mouseSpeed * float( prev_ypos - ypos );

		prev_xpos = xpos;
		prev_ypos = ypos;
    }
	else if(isRMousePressed){
		double xpos, ypos;
		glfwGetCursorPos(window, &xpos, &ypos);

		target.x += mouseSpeed * float(prev_R_xpos - xpos ) * 30;
		target.y += mouseSpeed * float( prev_R_ypos - ypos ) * 30;

		prev_R_xpos = xpos;
		prev_R_ypos = ypos;
	}
	else{
		glfwGetCursorPos(window, &prev_xpos, &prev_ypos);
		glfwGetCursorPos(window, &prev_R_xpos, &prev_R_ypos);
	}

	// Move the main light upward
	if (glfwGetKey( window, GLFW_KEY_UP ) == GLFW_PRESS){
		lightRotMove += glm::vec3(0.0, 2.0, 0.0);
	}
	// Move the main light downward
	if (glfwGetKey( window, GLFW_KEY_DOWN ) == GLFW_PRESS){
		lightRotMove += glm::vec3(0.0, -2.0, 0.0);
	}
	// Move the main light right
	if (glfwGetKey( window, GLFW_KEY_RIGHT ) == GLFW_PRESS){
		lightRotMove += glm::vec3(2.0, 0.0, 0.0);
	}
	// Move the main light left
	if (glfwGetKey( window, GLFW_KEY_LEFT ) == GLFW_PRESS){
		lightRotMove += glm::vec3(-2.0, 0.0, 0.0);
	}
	// Move the main light forward
	if (glfwGetKey( window, GLFW_KEY_PAGE_UP ) == GLFW_PRESS){
		lightRotMove += glm::vec3(0.0, 0.0, 0.3);
		if(lightRotMove[2]>3.0) lightRotMove[2] = 3.0;
	}
	// Move the main light left
	if (glfwGetKey( window, GLFW_KEY_PAGE_DOWN ) == GLFW_PRESS){
		lightRotMove += glm::vec3(0.0, 0.0, -0.3);
		if(lightRotMove[2]<0.1) lightRotMove[2] = 0.1;
	}
	// , < key
	if(glfwGetKey( window, GLFW_KEY_COMMA) == GLFW_PRESS){
		normalMode = 0; // use the surface normal
	}		
	// . > key
	if(glfwGetKey( window, GLFW_KEY_PERIOD) == GLFW_PRESS){
		normalMode = 1; // use the fine normal
	}		
	// R key
	if(glfwGetKey( window, GLFW_KEY_R) == GLFW_PRESS){
		textureMode = 0; // no texture
	}	
	// T key
	if(glfwGetKey( window, GLFW_KEY_T) == GLFW_PRESS){
		textureMode = 1; // texture
	}
	// Y key
	if(glfwGetKey( window, GLFW_KEY_Y) == GLFW_PRESS){
		textureMode = 2; // surface normal map
	}
	// U key
	if(glfwGetKey( window, GLFW_KEY_U) == GLFW_PRESS){
		textureMode = 3; // fine normal map
	}	
	// D key
	if(glfwGetKey( window, GLFW_KEY_D) == GLFW_PRESS){
		useSSSS = false; // turn off subsurface scattering
	}
	// S key
	if(glfwGetKey( window, GLFW_KEY_S) == GLFW_PRESS){
		useSSSS = true; // turn on subsurface scattering
	}
	// Z key
	if(glfwGetKey( window, GLFW_KEY_Z) == GLFW_PRESS){
		envMode = 0;
	}
	// X key
	if(glfwGetKey( window, GLFW_KEY_X) == GLFW_PRESS){
		envMode = 1;
	}
	// C key
	if(glfwGetKey( window, GLFW_KEY_C) == GLFW_PRESS){
		envMode = 2;
	}
	// O key
	if(glfwGetKey( window, GLFW_KEY_O) == GLFW_PRESS){
		useLight = true;
	}
	// P key
	if(glfwGetKey( window, GLFW_KEY_P) == GLFW_PRESS){
		useLight = false;
	}
	// Q key
	if(glfwGetKey( window, GLFW_KEY_Q) == GLFW_PRESS){
		exposure -= 0.1;
		if(exposure<0)
			exposure = 0.0;
	}
	// W key
	if(glfwGetKey( window, GLFW_KEY_W) == GLFW_PRESS){
		exposure += 0.1;
	}
	glm::mat3x3 rotmat_y(cos(horizontalAngle), 0.0, sin(horizontalAngle), 0.0, 1.0, 0.0, -sin(horizontalAngle), 0.0, cos(horizontalAngle));
	glm::mat3x3 rotmat_x(1.0, 0.0, 0.0, 0.0, cos(verticalAngle), -sin(verticalAngle), 0.0, sin(verticalAngle), cos(verticalAngle));
	glm::mat3x3 rotmat = rotmat_x * rotmat_y;

	position = rotmat * (glm::vec3(0.0, 0.0, currentRadius) - target) + target;
	glm::vec3 up = rotmat * glm::vec3(0.0, -1.0, 0.0);

	float FoV = initialFoV;

    int scrWidth, scrHeight;
    glfwGetFramebufferSize(window, &scrWidth, &scrHeight);
	// Projection matrix : 45� Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
	ProjectionMatrix = glm::perspective(glm::radians(FoV), (float)scrWidth/scrHeight, 10.0f, 1500.0f);
	// Camera matrix
	ViewMatrix       = glm::lookAt(
								position,           // Camera is here
								target, //position+direction, // and looks here : at the same position, plus "direction"
								up                  // Head is up (set to 0,-1,0 to look upside-down)
						   );
}