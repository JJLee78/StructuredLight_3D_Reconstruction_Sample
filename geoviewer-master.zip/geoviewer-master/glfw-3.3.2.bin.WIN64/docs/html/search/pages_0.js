var searchData=
[
  ['bug_20list_776',['Bug List',['../bug.html',1,'']]],
  ['building_20applications_777',['Building applications',['../build_guide.html',1,'']]]
];
