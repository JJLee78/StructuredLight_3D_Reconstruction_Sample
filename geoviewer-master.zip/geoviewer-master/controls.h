#ifndef CONTROLS_HPP
#define CONTROLS_HPP

void computeMatricesFromInputs();
glm::mat4 getViewMatrix();
glm::mat4 getProjectionMatrix();
glm::vec3 getCameraPosition();
int getNormalDisplayMode();
int getTextureMode();
bool getSSSSMode();
int getEnvmapMode();
bool getUseExtraLights();
glm::vec3 getLightRot();
float getFov();
float getExposure();

void setTarget(glm::highp_f64vec3 obj_target);

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);

#endif