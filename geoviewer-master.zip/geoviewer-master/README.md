This is an OpenGL based geometric image viewer.

It includes:
- preprocessing module to convert an input geometric image to polygonal mesh
- physically based OpenGL shading w/ textures including normal maps.
- image based ambient lighting (IBL) w/ HDR images
- spotlights for adding more highlights
- shadow mapping for each spotlights
- screen space ambient occlusion (SSAO)
- screen space subsurface scattering (separable SSSS)


**[How to build]**
- basically, this project was built with gcc on MS Visual Studio Code.
- install mingw-64 from http://mingw-w64.org/doku.php/download/mingw-builds if not installed before.
- open the working folder in VS Code
- change mingw paths in ./vscode/c_cpp_properties.json, launch.json, and tasks.json to the location you installed
- open GeoViewer.cpp in VS Code and build by running Terminal>Run Build Task... menu. (Caution: build the project always with GeoViewer.cpp opened. If not, other exe will be created.)
- open a terminal in VS Code and execute GeoViewer.exe.


**[Usages]**
- place input files (geometric image(.dat), texture(.bmp), normal files(.nor & .dat) to the working folder.
- run GeoViewer.exe to load and visualize the input data.


**[Keys]**


Texture Mode:
- r: surface shading (no texture, default)
- t: textured shading (color map)
- y: textured shading (surface normal map)
- u: textured shading (fine normal map)


Normal Mode:
- ,: use surface normal as normals (default)
- .: use fine normal as normals


Subsurface Scattering Mode:
- s: turn on subsurface scattering for skin (default)
- d: turn off subsurface scattering


Background Mode:
- z: environment map = cubemap as is (default)
- x: environment map = irrandiance map (blurred cubemap)
- c: environment map: turned off (black backgrounds)


Lights:
- o: turn on spotlights
- p: turn off spotlights (default)


Light Position Control:
- up/down/left/right arrows & page up/down: moving the first light (main light)


Exposure:
- q: current exposure - 0.1  (default: 2.0) 
- w: current exposure + 0.1  (default: 2.0)



**[Other Information]**

Free HDR images are available at:
- https://hdrihaven.com/hdris/?c=indoor
- http://www.hdrlabs.com/sibl/archive.html

How to generate a synthetic HDR image with Blender:
- https://b3d.interplanety.org/en/making-your-own-studio-hdri-in-blender/